import React from 'react';
import Counters from './components/counters';
//import { Movies } from './components/movies';

export function App(props) {
  return (
    <main className="container">
      <Counters />
    </main>
  );
}
