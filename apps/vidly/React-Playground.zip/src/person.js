export class Person {
    constructor(name) {
        this.name = name;
    }

    walk() {
        return('walk');
    }
}